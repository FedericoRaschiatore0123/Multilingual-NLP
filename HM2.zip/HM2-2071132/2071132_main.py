import sys
import argparse
import subprocess

def install_dependencies():
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        subprocess.check_call([sys.executable, "-m", "spacy", "download", "en_core_web_sm"])
    except subprocess.CalledProcessError as e:
        print(f"Failed to install dependencies: {e}")
        sys.exit(1)

def main(mode, dataset_type):
    install_dependencies()

    from datasets import load_dataset, load_metric
    from transformers import Trainer, TrainingArguments, DataCollatorWithPadding, get_linear_schedule_with_warmup
    import torch
    import torch.nn as nn
    from torch.optim import Adam
    from transformers import AutoTokenizer, AutoModel
    import spacy

    from model_training_evaluation import CrossEncoderClassifier, compute_metrics, NLIDataset, BiEncoderClassifier, Splitted_NLI_Dataset
    nlp = spacy.load("en_core_web_sm")
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # Parameters
    model_name = 'huawei-noah/TinyBERT_General_4L_312D'
    out_classes = 3
    fine_tune = True
    epochs = 3
    learning_rate = 1e-4
    batch_size = 64
    transform = False

    tokenizer = AutoTokenizer.from_pretrained(model_name)

    # Load datasets
    if dataset_type == 'original':
        dataset = load_dataset("tommasobonomo/sem_augmented_fever_nli")
    elif dataset_type == 'adversarial':
        dataset = load_dataset("tommasobonomo/sem_augmented_fever_nli")
        adversarial_dataset = load_dataset("iperbole/adversarial_fever_nli")
        transform = True
    else:
        raise ValueError("Invalid dataset type. Choose 'original' or 'adversarial'.")

    print("------------------------CROSS ENCODER TRANSFORMER------------------------")
    train_dataset = NLIDataset(dataset['train'], tokenizer, transform= transform)
    validation_dataset = NLIDataset(dataset['validation'], tokenizer, transform= transform)

    if transform:
        test_dataset = NLIDataset(adversarial_dataset['test'], tokenizer)
    else:
        test_dataset = NLIDataset(dataset['test'], tokenizer)

    # Initialize model and trainer
    cross_encoder_model = CrossEncoderClassifier(model_name, out_classes, fine_tune=fine_tune).to(device)

    training_args = TrainingArguments(
        output_dir="training_dir_cross_encoder_model",
        num_train_epochs=epochs,
        per_device_train_batch_size=batch_size,
        per_device_eval_batch_size=batch_size,
        warmup_steps=500,
        weight_decay=0.001,
        save_strategy="no",
        learning_rate=learning_rate,
        evaluation_strategy="epoch",
        logging_dir='./logs',
        logging_steps=10,
    )

    data_collator = DataCollatorWithPadding(tokenizer=tokenizer)
    optimizer = Adam(cross_encoder_model.parameters(), lr=learning_rate)
    scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=training_args.warmup_steps,
        num_training_steps=training_args.num_train_epochs * len(train_dataset) // training_args.per_device_train_batch_size
    )
    
    trainer = Trainer(
        model=cross_encoder_model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=validation_dataset,
        tokenizer=tokenizer,
        data_collator=data_collator,
        compute_metrics=compute_metrics,
        optimizers=(optimizer, scheduler)
    )

    if mode == 'train':
        trainer.train()
        trainer.evaluate()
    elif mode == 'test':
        test_results = trainer.predict(test_dataset)
        print(test_results.metrics)
    else:
        raise ValueError("Invalid mode. Choose 'train' or 'test'.")
    
    print("------------------------BI ENCODER TRANSFORMER------------------------")
    splitted_train_dataset = Splitted_NLI_Dataset(dataset['train'], tokenizer)
    splitted_validation_dataset = Splitted_NLI_Dataset(dataset['validation'], tokenizer)
    test_dataset = Splitted_NLI_Dataset(dataset['test'], tokenizer)

    bi_encoder_model = BiEncoderClassifier(model_name, out_classes, fine_tune=fine_tune).to(device)

    training_args = TrainingArguments(
        output_dir="training_dir_bi_encoder_model",
        num_train_epochs=epochs,
        per_device_train_batch_size=batch_size,
        per_device_eval_batch_size=batch_size,
        warmup_steps=500,
        weight_decay=0.001,
        save_strategy="no",
        learning_rate=learning_rate,
        eval_strategy="epoch",
        logging_dir='./logs',
        logging_steps=10,
    )

    data_collator = DataCollatorWithPadding(tokenizer=tokenizer)
    optimizer = Adam(bi_encoder_model.parameters(), lr=learning_rate)
    scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=training_args.warmup_steps,
        num_training_steps=training_args.num_train_epochs * len(splitted_train_dataset) // training_args.per_device_train_batch_size
    )

    trainer = Trainer(
        model=bi_encoder_model,
        args=training_args,
        train_dataset=splitted_train_dataset,
        eval_dataset=splitted_validation_dataset,
        tokenizer=tokenizer,
        data_collator=data_collator,
        compute_metrics=compute_metrics,
        optimizers=(optimizer, scheduler)
    )

    if mode == 'train':
        trainer.train()
        trainer.evaluate()
    elif mode == 'test':
        test_results = trainer.predict(test_dataset)
        print(test_results.metrics)
    else:
        raise ValueError("Invalid mode. Choose 'train' or 'test'.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["train", "test"], help="Mode: train or test the model")
    parser.add_argument("--data", choices=["original", "adversarial"], required=True, help="Dataset type: original or adversarial")

    args = parser.parse_args()
    main(args.mode, args.data)
