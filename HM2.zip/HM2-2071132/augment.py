import nltk

nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('averaged_perceptron_tagger')
nltk.download('punkt')
nltk.download('omw-1.4')

import spacy
from nltk.corpus import wordnet as wn
from nltk.tokenize import word_tokenize ,sent_tokenize
from nltk.tag import pos_tag
from nltk.corpus.reader.wordnet import Lemma
import random
import re
from spacy.lang.en.stop_words import STOP_WORDS
from string import punctuation
import networkx as nx
from transformers import DistilBertTokenizer, DistilBertModel, AutoTokenizer, AutoModel
from nltk.wsd import lesk
import torch
from nltk.corpus.reader.wordnet import Synset

nlp = spacy.load('en_core_web_sm')

device = "cuda" if torch.cuda.is_available() else "cpu"
model_name = 'huawei-noah/TinyBERT_General_4L_312D'
bert_tokenizer = AutoTokenizer.from_pretrained('bert-base-cased')
bert_model = AutoModel.from_pretrained('bert-base-cased').to(device)


distill_bert_tokenizer = DistilBertTokenizer.from_pretrained(model_name)
distill_bert_model = DistilBertModel.from_pretrained(model_name, output_attentions=True).to(device)

def clean_token(token):
    """
    Cleans a given token by removing specific special tokens, non-alphanumeric characters,
    and short tokens (length <= 3).

    Args:
        token (str): The token to be cleaned.

    Returns:
        str: The cleaned token.
    """
    if isinstance(token, str):
        token = re.sub(r'[SEP]', '', token)
    if isinstance(token, str):
        token = re.sub(r'[CLS]', '', token)
    if isinstance(token, str):
        token = re.sub(r'[^a-zA-Z0-9\s]', '', token)
    if len(token) <= 3:
        token = ''
    return token

def textrank(text, top_n=5, window_size = 100):
    """
    Extracts the top N important words from a text using the TextRank algorithm.

    Args:
        text (str): The input text.
        top_n (int): The number of top words to extract.

    Returns:
        list: A list of the top N important words.
    """
    doc = nlp(text)
    stop_words = set(STOP_WORDS)
    pos_tag = ['NOUN', 'ADJ', 'VB', 'ADV']

    words = [token.text.lower() for token in doc if  token.text.lower() not in stop_words and token.text not in punctuation]

    graph = nx.Graph()
    graph.add_nodes_from(words)

    for i in range(len(words)):
        for j in range(i + 1, i + window_size):
            if j >= len(words):
                break
            graph.add_edge(words[i], words[j])

    scores = nx.pagerank(graph)
    ranked_words = sorted(scores, key=scores.get, reverse=True)
    return ranked_words[:top_n]

def extract_proper_nouns(text):
    """
    Extracts proper nouns

    Args:
        text (str): The input text.

    Returns:
        list: A list of tuples containing proper nouns and their character positions.
    """
    doc = nlp(text)
    nouns = [ent.text for ent in doc.ents if ent.label_ in ['PERSON', 'ORG', 'GPE', 'LOC']]

    proper_nouns=[]
    for noun in nouns:
        proper_nouns = proper_nouns + noun.split(" ")

    return proper_nouns

def find_important_words(sentence, device='cpu', max_num=5):
    """
    Identifies the most important words in a sentence based on attention scores from a BERT model.

    Args:
        sentence (str): The input sentence.
        device (str): device
        max_num (int): The maximum number of important words to return.

    Returns:
        list: A list of tuples containing the important words and their attention scores.
    """
    inputs = distill_bert_tokenizer(sentence, return_tensors='pt', truncation=True, padding=True).to(device)

    with torch.no_grad():
        outputs = distill_bert_model(**inputs)

    attentions = outputs.attentions
    mean_attentions = torch.stack(attentions).mean(dim=1).mean(dim=1).squeeze(0).mean(dim=0).mean(dim=0)
    tokens = distill_bert_tokenizer.convert_ids_to_tokens(inputs['input_ids'].squeeze(0))

    token_attention_pairs = []
    for token, attention in zip(tokens, mean_attentions):
        cleaned_token = clean_token(token)
        if cleaned_token:
            token_attention_pairs.append((cleaned_token, attention))

    token_attention_pairs.sort(key=lambda x: x[1], reverse=True)

    return token_attention_pairs[:max_num]

def replace_word(synset):
    if isinstance(synset, list):
        synset = random.choice(synset)

    if not isinstance(synset, Synset):
        return False, synset

    lemma = synset.lemmas()[0]
    pos = synset.pos()

    if pos in ['v']:
        antonyms = lemma.antonyms()
        if antonyms:
            return True, random.choice(antonyms).name()

        synonyms = [l.name() for l in synset.lemmas() if l.name() != lemma.name()]
        if synonyms:
            return False, random.choice(synonyms)

    elif pos == 'n':
        synonyms = [l.name() for l in synset.lemmas() if l.name() != lemma.name()]
        hypernyms = synset.hypernyms()
        hyponyms = synset.hyponyms()

        if synonyms:
            return False, random.choice(synonyms)
        elif hypernyms:
            return False, random.choice(hypernyms).lemmas()[0].name()
        elif hyponyms:
            return False, random.choice(hyponyms).lemmas()[0].name()

    return False, lemma.name()


def remove_nouns(key_words, nouns):
    """
    Removes proper nouns from a list of keywords.

    Args:
        key_words (list): The list of keywords.
        nouns (list): The list of proper nouns.

    Returns:
        list: The filtered list of keywords without proper nouns.
    """
    single_nouns = []
    for noun in nouns:
          single_nouns.append(noun.lower())

    return [word for word in key_words if word.lower() not in single_nouns]

def word_tokenizer(text):
    """
    Tokenizes a sentence and returns tokens with their start and end indices.

    Args:
        text (str): The input text.

    Returns:
        list: A list of tuples containing the token, start index, and end index.
    """
    doc = nlp(text)
    tokens_with_indices = [ token.text for i, token in enumerate(doc)]
    return tokens_with_indices

def transform_sentence(sentence):
    """
    Transforms a sentence by substituting important keywords with their synsets.

    Args:
        sentence (str): The input sentence.

    Returns:
        str: The transformed sentence with substituted keywords.
    """
    word_list = textrank(sentence)

    nouns = extract_proper_nouns(sentence)
    words = sentence.lower().split()
    word_list = remove_nouns(word_list, nouns)

    word_sense = []
    tokens = word_tokenizer(sentence)

    invert = False

    for word in word_list:
        synset = lesk(sentence.split(), word)
        invert = False

        if word in tokens:
          index = tokens.index(word)
          inv, new_word = replace_word(synset)
          if inv:
            invert = True
          if not new_word:
              new_word = word
          tokens[index] = new_word
    sentence = ' ' .join(tokens)

    return invert,  sentence
