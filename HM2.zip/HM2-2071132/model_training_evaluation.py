import numpy as np
from transformers import AutoModel, AutoTokenizer, Trainer, TrainingArguments, DataCollatorWithPadding
import torch
from torch.utils.data import Dataset
import torch.nn as nn
from torch.optim import Adam
from datasets import load_metric
from augment import transform_sentence


device = "cuda" if torch.cuda.is_available() else "cpu"

class NLIDataset(Dataset):
    def __init__(self, dataset, tokenizer, max_length=128, transform=False):
        self.dataset = dataset
        self.transform = transform
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.premises = [word for word in self.dataset['premise']]
        self.hypothesis = [word for word in self.dataset['hypothesis']]
        self.labels = self.dataset['label']

    def __len__(self):
        return len(self.dataset['premise'])

    def __getitem__(self, idx):
        if self.transform:
            invert, transformed_sentence = transform_sentence(self.hypothesis[idx])
            inputs = self.tokenizer(
                self.premises[idx],
                transformed_sentence,
                padding='max_length',
                truncation=True,
                max_length=self.max_length,
                return_tensors="pt"
            ).to(device)
            inputs = {key: val.squeeze(0) for key, val in inputs.items()}
            if invert:
                inputs['labels'] = torch.tensor(self.invert_labels(self.labels[idx]))
            else:
                inputs['labels'] = torch.tensor(self.convert_labels(self.labels[idx]))
        else:
            inputs = self.tokenizer(
                self.premises[idx],
                self.hypothesis[idx],
                padding='max_length',
                truncation=True,
                max_length=self.max_length,
                return_tensors="pt"
            ).to(device)
            inputs = {key: val.squeeze(0) for key, val in inputs.items()}
            inputs['labels'] = torch.tensor(self.convert_labels(self.labels[idx]))
        return inputs

    def convert_labels(self, label):
        label_map = {"ENTAILMENT": 0, "NEUTRAL": 1, "CONTRADICTION": 2}
        return label_map[label]

    def invert_labels(self, label):
        label_map = {"ENTAILMENT": 2, "NEUTRAL": 1, "CONTRADICTION": 0}
        return label_map[label]
    

class Splitted_NLI_Dataset(Dataset):
    def __init__(self, dataset, tokenizer, max_length=128, transform = False):
        self.dataset = dataset
        self.transform = transform

        self.tokenizer = tokenizer
        self.max_length = max_length

        self.premises = [word for word in self.dataset['premise']]
        self.hypothesis = [word for word in self.dataset['hypothesis']]
        self.labels = self.dataset['label']


    def __len__(self):
        return len(self.dataset['premise'])

    def __getitem__(self, idx):

        inputs1 = self.tokenizer(
                    self.premises[idx],
                    padding='max_length',
                    truncation=True,
                    max_length=self.max_length,
                    return_tensors="pt",
                  ).to(device)

        if self.transform:
          invert, transformed_sentence = transform_sentence(self.hypothesis[idx])
          inputs2 = self.tokenizer(
                    transformed_sentence,
                    padding='max_length',
                    truncation=True,
                    max_length=self.max_length,
                    return_tensors="pt",
                  ).to(device)

          inputs = {
              "input_ids" : [inputs1['input_ids'],inputs2['input_ids']],
              "attention_mask" : [inputs1['attention_mask'],inputs2['attention_mask']]
            }

          if invert:
                inputs['labels'] = torch.tensor(self.invert_labels(self.labels[idx]))
          else:
                inputs['labels'] = torch.tensor(self.convert_labels(self.labels[idx]))

        else:
          inputs2 = self.tokenizer(
                      self.hypothesis[idx],
                      padding='max_length',
                      truncation=True,
                      max_length=self.max_length,
                      return_tensors="pt",
                    ).to(device)


          inputs = {
            "input_ids" : [inputs1['input_ids'],inputs2['input_ids']],
            "attention_mask" : [inputs1['attention_mask'],inputs2['attention_mask']]
          }
          inputs['labels'] = torch.tensor(self.convert_labels(self.labels[idx]))
        return inputs

    def convert_labels(self, label):
        label_map = {"ENTAILMENT": 0, "NEUTRAL": 1, "CONTRADICTION": 2}
        return label_map[label]

    def invert_labels(self, label):
        label_map = {"ENTAILMENT": 2, "NEUTRAL": 1, "CONTRADICTION": 0}
        return label_map[label]
    
def compute_metrics(eval_pred):
    from datasets import load_metric
    
    load_accuracy = load_metric("accuracy", trust_remote_code=True)
    load_f1 = load_metric("f1", trust_remote_code=True)
    load_recall = load_metric("recall", trust_remote_code=True)
    load_precision = load_metric("precision", trust_remote_code=True)
    
    logits, labels = eval_pred
    predictions = np.argmax(logits, axis=-1)
    
    accuracy = load_accuracy.compute(predictions=predictions, references=labels)["accuracy"]
    f1 = load_f1.compute(predictions=predictions, references=labels, average='weighted')["f1"]
    recall = load_recall.compute(predictions=predictions, references=labels, average='weighted')["recall"]
    precision = load_precision.compute(predictions=predictions, references=labels, average='weighted')["precision"]
    
    return {"accuracy": accuracy, "f1": f1, "recall": recall, "precision": precision}

class CrossEncoderClassifier(nn.Module):
    def __init__(self, model_name, out_classes, fine_tune=True, dropout=0.3):
        super().__init__()
        self.out_classes = out_classes

        self.transformer = AutoModel.from_pretrained(model_name, output_hidden_states=True)

        for param in self.transformer.parameters():
            param.requires_grad = fine_tune

        self.dropout = nn.Dropout(dropout)

        self.classifier = nn.Sequential(
            nn.Linear(self.transformer.config.hidden_size, self.transformer.config.hidden_size // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(self.transformer.config.hidden_size // 2, out_classes)
        )
        self.criterion = nn.CrossEntropyLoss()

    def forward(self, input_ids=None, attention_mask=None,  labels=None, compute_predictions=False, compute_loss=True):
        model_args = {
            "input_ids": input_ids,
            "attention_mask": attention_mask
        }
        outputs = self.transformer(**model_args)
        hidden_states = outputs.hidden_states[-4:]

        transformers_outputs_sum = torch.stack(hidden_states, dim=0).sum(dim=0)
        transformers_outputs_sum = self.dropout(transformers_outputs_sum)

        logits = self.classifier(self.dropout(transformers_outputs_sum)).mean(dim=1)

        output = {"logits": logits}

        if compute_predictions:
            predictions = logits.argmax(dim=-1)
            output["predictions"] = predictions

        if compute_loss and labels is not None:
            output["loss"] = self.criterion(logits, labels)

        return output
    

class BiEncoderClassifier(nn.Module):
    def __init__(self, model_name, out_classes, fine_tune=True, dropout=0.3, *args, **kwargs):
        super().__init__()
        self.out_classes = out_classes
        self.transformer = AutoModel.from_pretrained(model_name, output_hidden_states=True)

        if not fine_tune:
            for param in self.parameters():
                param.requires_grad = False

        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Sequential(
            nn.Linear(self.transformer.config.hidden_size * 2, self.transformer.config.hidden_size ),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(self.transformer.config.hidden_size , out_classes)
        )

        self.criterion = nn.CrossEntropyLoss()

    def forward(self, input_ids=None, attention_mask=None, token_type_ids=None, labels=None, compute_predictions=False, compute_loss=True):
        model_args1 = {"input_ids": input_ids[:,0,0].to(device), "attention_mask": attention_mask[:,0,0].to(device)}
        model_args2 = {"input_ids": input_ids[:,1,0].to(device), "attention_mask": attention_mask[:,1,0].to(device)}

        outputs1 = self.transformer(**model_args1)
        outputs2 = self.transformer(**model_args2)

        hidden_states1 = outputs1.hidden_states[-4:]
        transformers_outputs_sum1 = torch.stack(hidden_states1, dim=0).sum(dim=0).mean(dim=1)

        hidden_states2 = outputs2.hidden_states[-4:]
        transformers_outputs_sum2 = torch.stack(hidden_states2, dim=0).sum(dim=0).mean(dim=1)

        concatenated_output = torch.cat((transformers_outputs_sum1, transformers_outputs_sum2), dim=1)
        concatenated_output = self.dropout(concatenated_output)

        logits = self.classifier(concatenated_output)

        output = {"logits": logits}

        if compute_predictions:
            predictions = logits.argmax(dim=-1)
            output["predictions"] = predictions

        if compute_loss and labels is not None:
            output["loss"] = self.criterion(logits, labels)

        return output
